package com.stu26172.googlemapsapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState

@Composable
fun HomePage(modifier: Modifier = Modifier) {

    // State variables for latitude and longitude input
    var latitudeInput by remember { mutableStateOf(" -23.533773") }
    var longitudeInput by remember { mutableStateOf("-46.625290 ") }
    val userInput = LatLng(latitudeInput.toDoubleOrNull() ?: 0.0, longitudeInput.toDoubleOrNull() ?: 0.0)

    // Camera position state for Google Map
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(userInput, 10f)
    }

    Column(modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        var markerPosition by remember { mutableStateOf<LatLng?>(null) }

        Spacer(modifier = Modifier.height(100.dp))

        Text(text = "Input fields for latitude and longitude"

        )


        Row(modifier = Modifier.padding(16.dp)) {
            TextField(
                value = latitudeInput,
                onValueChange = { latitudeInput = it },
                label = { Text("Latitude") },
                modifier = Modifier.weight(1f).padding(end = 8.dp)
            )
            TextField(
                value = longitudeInput,
                onValueChange = { longitudeInput = it },
                label = { Text("Longitude") },
                modifier = Modifier.weight(1f)
            )
        }

        Button(
            onClick = {
                val lat = latitudeInput.toDoubleOrNull()
                val lng = longitudeInput.toDoubleOrNull()
                if (lat != null && lng != null) {
                    markerPosition = LatLng(lat, lng)
                }
            },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("Place Marker")
        }

        // Google Map
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState
        ) {
            val markerPosition = LatLng(
                latitudeInput.toDoubleOrNull() ?: 0.0,
                longitudeInput.toDoubleOrNull() ?: 0.0
            )
            markerPosition?.let {
                Marker(
                    state = MarkerState(position = it),
                    title = "Custom Marker",
                    snippet = "Marker at user-specified location",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)
                )
            }

        }

        // Update the camera position when latitude or longitude changes
        LaunchedEffect(latitudeInput, longitudeInput) {
            val lat = latitudeInput.toDoubleOrNull()
            val lng = longitudeInput.toDoubleOrNull()
            if (lat != null && lng != null) {
                cameraPositionState.position = CameraPosition.fromLatLngZoom(LatLng(lat, lng), 10f)
            }
        }
    }

}